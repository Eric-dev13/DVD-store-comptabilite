export enum GenreEnum {
  ACTION='Action',
  DRAMA='Drama',
  COMEDIE='Comedie',
  HORROR='Horreur',
  THRILLER='Thriller',
  SCIENCE_FICTION='Sci-fy'
}
